public class Text {
    String question(int nArray, int nAnswer) {
        String[][] pagetitles = {
            {
                "Cachorros e gatos não se odeiam tanto assim... Portanto, qual dessas raças de cachorro você mais gosta?",
                "Nenhum, só gosto de gatos...",
                "Lulu da Pomerânia",
                "Shiba inu (doge)",
                "Vira-lata caramelo",
                "Buldogue inglês",
                "Pitbull" 
            },
            {
                "Onde você tiraria uma ótima soneca se você fosse um gato?",
                "Em cima da cova",
                "No tapete de pelinhos",
                "No teclado led",
                "No banco da praça",
                "No aparelho de leg press",
                "Na barbearia gourmet"
            },
            {
                "Qual peça de roupa não pode faltar no seu armário? ",
                "Meia arrastão",
                "Saia plissada",
                "Moletom",
                "Peitas do meu timão",
                "Regatinha cavada",
                "Correntinha"
            },
            {
                "Qual desses sons te traz mais paz?  ",
                "Apenas o silêncio ou a banda que só eu conheço",
                "Lo-fi",
                "O doce som de quando guanho uma batalha",
                "O rantatá da minha motinho empinando",
                "Quando solto de propósito os pesos no chão",
                "O mega do momento"
            },
            {
                "Para que você mais usa seu celular?",
                "Ficar no Twitter",
                "Ver edits do meu cantor favorito",
                "Avisar que vou entrar no discord",
                "Conectar o bluetooth pro meu radiozinho",
                "Tirar foto no espelho",
                "Postar story com os mano"
            },
            {
                "Dentre essas, qual sua cor preferida? ",
                "Vermelho",
                "Rosa",
                "Roxo",
                "Verde",
                "Azul",
                "Preto"
            },
            {
                "Se você fosse sair, para qual desses lugares você iria? ",
                "não sairia",
                "cafeteria",
                "ficaria em casa jogando",
                "revoada",
                "academia",
                "shed"
            },
            {
                "Entre esses qual seu gênero musical preferido? ",
                "rock",
                "pop",
                "eletronica",
                "funk",
                "phonk",
                "sertanejo"
            },
            {
                "Qual tipo de filme você prefere? ",
                "terror",
                "romance",
                "ficção científica",
                "comédia",
                "suspense",
                "ação"
            },
            {
                "Qual dessas bebidas você prefere? ",
                "café",
                "chá gelado",
                "energético",
                "corote",
                "whey",
                "cerveja"
            }
            };
        return pagetitles[nArray][nAnswer];
        }
    
   
    public final String emoText = "Você vive nas trevas, adora preto, não sai de casa e não tem amigos.";
    public final String emoImagePath = "emo.jpeg";
    public final String emoTitle = "Você é um gatinho emo!";

    public final String softText = "Você ama a cor rosa e tons pastéis, tem um estilo delicado e ama ir em cafeterias.";
    public final String softImagePath = "fofo.jpeg";
    public final String softTitle = "Você é um gatinho soft!";

    public final String gamerText = "Você troca suas noites de sono por jogos, sofre por não subir de elo e vive tiltado com seu time.";
    public final String gamerImagePath = "gamer.jpeg";
    public final String gamerTitle = "Você é um gatinho gamer!";

    public final String criaText = "Você não perde uma festa, tem risquinho na sobrancelha e não pode esquecer seu pod.";
    public final String criaImagePath = "cria.jpeg";
    public final String criaTitle = "Você é um gatinho cria!";

    public final String marombaText = "Você carrega sua coqueteleira com whey em todos os lugares, não perde um treino e adora exibir seus bíceps.";
    public final String marombaImagePath = "maromba.jpeg";
    public final String marombaTitle = "Você é um gatinho maromba!";

    public final String heterotopText = "Você adora ir na Shed usando camiseta preta e correntinha. Seu passatempo favorito é tomar campari e ir atrás das fêmeas.";
    public final String heterotopImagePath = "heterotop.png";
    public final String heterotopTitle = "Você é um gatinho heterotop!";
    
}