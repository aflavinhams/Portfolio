import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import java.awt.*;

public class FinalPage {
  //public void main(String[] args) {
  //  SwingUtilities.invokeLater(() -> {
   //   createPage();
   // });
  //}

  public JPanel createPage(CardLayout cardLayout, JPanel contentPane, String title, String path, String text) {

    JPanel panel = new JPanel();
    panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

    JLabel titleLabel = new JLabel(title);
    Border currentBorder = titleLabel.getBorder();
    Border margin = new EmptyBorder(100, 0, 50, 0);
    titleLabel.setBorder(new CompoundBorder(currentBorder, margin));
    titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 50));
    titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    panel.add(titleLabel);

    ImageIcon imageIcon = new ImageIcon("./pages/images/" + path);
    Image resizedImage = imageIcon.getImage().getScaledInstance(450, 450, Image.SCALE_SMOOTH);
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    JLabel imageLabel = new JLabel(resizedIcon);

    imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    imageLabel.setAlignmentY(0.5f); // Centraliza verticalmente a imagem
    panel.add(imageLabel);

    JLabel subTextLabel = new JLabel(text);
    Border subMargin = new EmptyBorder(100, 0, 50, 0);
    subTextLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
    subTextLabel.setBorder(new CompoundBorder(currentBorder, subMargin));
    subTextLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    panel.add(subTextLabel);

    // Centraliza todos os componentes
    panel.setAlignmentX(Component.CENTER_ALIGNMENT);
    panel.setAlignmentY(Component.CENTER_ALIGNMENT);

    return panel;
  }
}