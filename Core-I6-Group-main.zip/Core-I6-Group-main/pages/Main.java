import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }

    static void createAndShowGUI() {
        Page page = new Page();
        Text text = new Text();
        JFrame frame = new JFrame("Simp le Interface");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        // Create a CardLayout for the content pane
        CardLayout cardLayout = new CardLayout();
        JPanel contentPane = new JPanel(cardLayout);
        frame.setContentPane(contentPane);

        // Create the first page
        JPanel firstPage = page.createPage(cardLayout, contentPane, "SecondPage", text.question(0, 0), 
            text.question(0, 1),text.question(0, 2), text.question(0, 3), 
            text.question(0, 4), text.question(0, 5), text.question(0, 6));
        contentPane.add(firstPage, "FirstPage");

        // Create the second page
        JPanel secondPage = page.createPage(cardLayout, contentPane, "ThirdPage", text.question(1, 0), 
            text.question(1, 1),text.question(1, 2), text.question(1, 3), 
            text.question(1, 4), text.question(1, 5), text.question(1, 6));
        contentPane.add(secondPage, "SecondPage");
        
        // Create the third page
        JPanel thirdPage = page.createPage(cardLayout, contentPane, "FourthPage", text.question(2, 0), 
            text.question(2, 1), text.question(2, 2), text.question(2, 3), 
            text.question(2, 4), text.question(2, 5), text.question(2, 6));
        contentPane.add(thirdPage, "ThirdPage");   

        // Create the fourth page
        JPanel fourthPage = page.createPage(cardLayout, contentPane, "FifthPage", text.question(3, 0), 
            text.question(3, 1), text.question(3, 2), text.question(3, 3), 
            text.question(3, 4), text.question(3, 5), text.question(3, 6));
        contentPane.add(fourthPage, "FourthPage");

        // Create the fifth page
        JPanel fifthPage = page.createPage(cardLayout, contentPane, "SixthPage", text.question(4, 0), 
            text.question(4, 1), text.question(4, 2), text.question(4, 3), 
            text.question(4, 4), text.question(4, 5), text.question(4, 6));
        contentPane.add(fifthPage, "FifthPage");

        // Create the sixth page
        JPanel sixthPage = page.createPage(cardLayout, contentPane, "SeventhPage", text.question(5, 0), 
            text.question(5, 1), text.question(5, 2), text.question(5, 3), 
            text.question(5, 4), text.question(5, 5), text.question(5, 6));
        contentPane.add(sixthPage, "SixthPage");

        // Create the seventh page
        JPanel seventhPage = page.createPage(cardLayout, contentPane, "EighthPage", text.question(6, 0), 
            text.question(6, 1), text.question(6, 2), text.question(6, 3), 
            text.question(6, 4), text.question(6, 5), text.question(6, 6));
        contentPane.add(seventhPage, "SeventhPage");

        // Create the eighth page
        JPanel eighthPage = page.createPage(cardLayout, contentPane, "NinthPage", text.question(7, 0), 
            text.question(7, 1), text.question(7, 2), text.question(7, 3), 
            text.question(7, 4), text.question(7, 5), text.question(7, 6));
        contentPane.add(eighthPage, "EighthPage");

        // Create the ninth page
        JPanel ninthPage = page.createPage(cardLayout, contentPane, "TenthPage", text.question(8, 0), 
            text.question(8, 1), text.question(8, 2), text.question(8, 3), 
            text.question(8, 4), text.question(8, 5), text.question(8, 6));
        contentPane.add(ninthPage, "NinthPage");

        // Create the tenth page
        JPanel tenthPage = page.createPage(cardLayout, contentPane, "EleventhPage", text.question(9, 0), 
            text.question(9, 1), text.question(9, 2), text.question(9, 3), 
            text.question(9, 4), text.question(9, 5), text.question(9, 6));
        contentPane.add(tenthPage, "TenthPage");

        frame.setVisible(true);
    }
}