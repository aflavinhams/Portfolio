import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

public class Page {
    CardLayout cardLayout = new CardLayout();
    JPanel contentPane = new JPanel(cardLayout);
    FinalPage finalPage = new FinalPage();
    Text text = new Text();
    int emoCounter = 0;
    int softCounter = 0;
    int gamerCounter = 0;
    int criaCounter = 0;
    int marombaCounter = 0;
    int heterotopCounter = 0;
    int listenerCounter = 0;
    int orderResult = 0;
    int[] counterArr = {emoCounter, softCounter, gamerCounter, criaCounter, marombaCounter, heterotopCounter};
    

    int order(){
        Arrays.sort(counterArr);
        if(counterArr[5] == emoCounter){
            return 1;
        }
        else if(counterArr[5] == softCounter){
            return 2;
        }
        else if(counterArr[5] == gamerCounter){
            return 3;
        }
        else if(counterArr[5] == criaCounter){
            return 4;
        }
        else if(counterArr[5] == marombaCounter){
            return 5;
        }
        else if(counterArr[5] == heterotopCounter){
            return 6;
        }
        else{
            return 0;
        }

    }
    public JPanel createPage(CardLayout cardLayout, JPanel contentPane, String page, String pergunta, String... answer) {
        JPanel panel = new JPanel(new GridBagLayout());
    
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(0, 0, 25, 0);
    
        JProgressBar progressBar = new JProgressBar(0, 100);
        progressBar.setPreferredSize(new Dimension(500, 35));
    
        panel.add(progressBar, gbc);
    
        gbc.gridy++;
        JLabel titleLabel = new JLabel(pergunta);
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
        panel.add(titleLabel, gbc);
    
        gbc.gridy++;
        JToggleButton button1 = new JToggleButton(answer[0]);
        button1.setFont(new Font("Times New Roman", Font.BOLD, 20));

        JToggleButton button2 = new JToggleButton(answer[1]);
        button2.setFont(new Font("Times New Roman", Font.BOLD, 20));

        JToggleButton button3 = new JToggleButton(answer[2]);
        button3.setFont(new Font("Times New Roman", Font.BOLD, 20));

        JToggleButton button4 = new JToggleButton(answer[3]);
        button4.setFont(new Font("Times New Roman", Font.BOLD, 20));

        JToggleButton button5 = new JToggleButton(answer[4]);
        button5.setFont(new Font("Times New Roman", Font.BOLD, 20));

        JToggleButton button6 = new JToggleButton(answer[5]);
        button6.setFont(new Font("Times New Roman", Font.BOLD, 20));

    
        Dimension toggleButtonSize = new Dimension(500, 50);
        button1.setPreferredSize(toggleButtonSize);
        button2.setPreferredSize(toggleButtonSize);
        button3.setPreferredSize(toggleButtonSize);
        button4.setPreferredSize(toggleButtonSize);
        button5.setPreferredSize(toggleButtonSize);
        button6.setPreferredSize(toggleButtonSize);
    
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(button1);
        buttonGroup.add(button2);
        buttonGroup.add(button3);
        buttonGroup.add(button4);
        buttonGroup.add(button5);
        buttonGroup.add(button6);
    
        panel.add(button1, gbc);
        gbc.gridy++;
        panel.add(button2, gbc);
        gbc.gridy++;
        panel.add(button3, gbc);
        gbc.gridy++;
        panel.add(button4, gbc);
        gbc.gridy++;
        panel.add(button5, gbc);
        gbc.gridy++;
        panel.add(button6, gbc);
    
        gbc.gridy++;
        JButton submitButton = new JButton("SUBMIT");
        submitButton.setFont(new Font("Times New Roman", Font.BOLD, 22));
        Dimension buttonSize = new Dimension(200, 50);
        submitButton.setBackground(Color.PINK);
        submitButton.setPreferredSize(buttonSize);
        panel.add(submitButton, gbc);
    
        // Add an ActionListener to the submit button to switch to the second page
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(button1.isSelected()){
                    emoCounter++;
                    counterArr[0] = emoCounter;
                }
                else if(button2.isSelected()){
                    softCounter++;
                    counterArr[1] = softCounter;
                }
                else if(button3.isSelected()){
                    gamerCounter++;
                    counterArr[2] = gamerCounter;
                }
                else if(button4.isSelected()){
                    criaCounter++;
                    counterArr[3] = criaCounter;
                }
                else if(button5.isSelected()){
                    marombaCounter++;
                    counterArr[4] = marombaCounter;
                }
                else if(button6.isSelected()){
                    heterotopCounter++;
                    counterArr[5] = heterotopCounter;
                }
                else{
                    return;
                }
                listenerCounter++;
                if(listenerCounter == 10){
                    orderResult = order();
                    System.out.println(orderResult);
                    switch(orderResult){
                        case 1:
                        JPanel elevenPage = finalPage.createPage(cardLayout, contentPane, text.emoTitle, text.emoImagePath, text.emoText);
                        contentPane.add(elevenPage, "EleventhPage");
                        break;
                        case 2:
                        JPanel twelfthPage = finalPage.createPage(cardLayout, contentPane, text.softTitle, text.softImagePath, text.softText);
                        contentPane.add(twelfthPage, "EleventhPage");
                        break;
                        case 3:
                        JPanel thirteenPage = finalPage.createPage(cardLayout, contentPane, text.gamerTitle, text.gamerImagePath, text.gamerText);
                        contentPane.add(thirteenPage, "EleventhPage");
                        break;
                        case 4:
                        JPanel fourteenPage = finalPage.createPage(cardLayout, contentPane, text.criaTitle, text.criaImagePath, text.criaText);
                        contentPane.add(fourteenPage, "EleventhPage");
                        break;
                        case 5:
                        JPanel fifteenPage = finalPage.createPage(cardLayout, contentPane, text.marombaTitle, text.marombaImagePath, text.marombaText);
                        contentPane.add(fifteenPage, "EleventhPage");
                        break;
                        case 6:
                        JPanel sixteenPage = finalPage.createPage(cardLayout, contentPane, text.heterotopTitle, text.heterotopImagePath, text.heterotopText);
                        contentPane.add(sixteenPage, "EleventhPage");
                        break;
                    }
                }
                else{
                    cardLayout.show(contentPane, page);
                }
            }
        });
    
        return panel;
    }
}